#pragma once
#include "Game.h"

// Hilo de plataformas móviles: mueve todas las plataformas horizontalmente
void* platformThread(void* arg);
