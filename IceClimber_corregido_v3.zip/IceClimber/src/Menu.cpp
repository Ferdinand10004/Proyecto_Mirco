#include "Menu.h"
#include "ScoreManager.h"
#include <vector>
#include <string>
#include <cstring>
#include <unistd.h>

// ─── Helper: centrar texto ────────────────────────────────────────────────────
static void centerPrint(int row, const char* text, int colorPair, bool bold = false) {
    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    (void)maxY;
    int col = (maxX - (int)strlen(text)) / 2;
    if (col < 0) col = 0;
    if (bold) attron(A_BOLD);
    attron(COLOR_PAIR(colorPair));
    mvprintw(row, col, "%s", text);
    attroff(COLOR_PAIR(colorPair));
    if (bold) attroff(A_BOLD);
}

// ─── Arte ASCII del título ────────────────────────────────────────────────────
static const char* TITLE_ART[] = {
    "  ___           ___  _ _         _",
    " |_ _|___ ___  / __|| (_)_ __  | |__  ___ _ _",
    "  | |/ __/ _ \\| (__ | | | '  \\ | '_ \\/ -_) '_|",
    " |___\\___\\___/ \\___||_|_|_|_|_||_.__/\\___|_|",
    "                                               "
};
static const int TITLE_LINES = 5;

// ─── Menú principal ───────────────────────────────────────────────────────────
MenuResult showMainMenu() {
    nodelay(stdscr, FALSE);  // bloqueante para el menú

    const std::vector<std::string> options = {
        "  Modo 1 Jugador  ",
        "  Modo 2 Jugadores",
        "  Instrucciones   ",
        "  Puntajes Altos  ",
        "  Salir           "
    };
    int selected = 0;

    while (true) {
        erase();
        int maxY, maxX;
        getmaxyx(stdscr, maxY, maxX);
        int startRow = maxY / 2 - 10;
        if (startRow < 0) startRow = 0;

        // ── Título ASCII Art ────────────────────────────────────────────
        for (int i = 0; i < TITLE_LINES; i++) {
            centerPrint(startRow + i, TITLE_ART[i], CP_GOAL, true);
        }

        centerPrint(startRow + TITLE_LINES + 1,
                    "~~~ Escala la montana de hielo ~~~", CP_PLATFORM);

        // ── Opciones del menú ───────────────────────────────────────────
        int optRow = startRow + TITLE_LINES + 4;
        for (int i = 0; i < (int)options.size(); i++) {
            if (i == selected) {
                attron(COLOR_PAIR(CP_MENU_SEL) | A_BOLD);
                centerPrint(optRow + i * 2, options[i].c_str(), CP_MENU_SEL, true);
                attroff(COLOR_PAIR(CP_MENU_SEL) | A_BOLD);
            } else {
                centerPrint(optRow + i * 2, options[i].c_str(), CP_HUD);
            }
        }

        centerPrint(optRow + (int)options.size() * 2 + 1,
                    "Flechas: navegar   Enter: seleccionar", CP_DEFAULT);

        refresh();

        int ch = getch();
        switch (ch) {
            case KEY_UP:
                selected = (selected - 1 + (int)options.size()) % (int)options.size();
                break;
            case KEY_DOWN:
                selected = (selected + 1) % (int)options.size();
                break;
            case '\n': case '\r': case KEY_ENTER:
                nodelay(stdscr, TRUE);  // volver a no bloqueante
                switch (selected) {
                    case 0: return MenuResult::PLAY_1P;
                    case 1: return MenuResult::PLAY_2P;
                    case 2: return MenuResult::INSTRUCTIONS;
                    case 3: return MenuResult::HIGH_SCORES;
                    case 4: return MenuResult::EXIT;
                }
                break;
            case 'q': case 'Q': case 27:
                nodelay(stdscr, TRUE);
                return MenuResult::EXIT;
        }
    }
}

// ─── Pantalla de instrucciones ────────────────────────────────────────────────
void showInstructions() {
    nodelay(stdscr, FALSE);
    erase();

    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    int r = 2;
    int cx = maxX / 2;

    attron(COLOR_PAIR(CP_GOAL) | A_BOLD);
    mvprintw(r++, cx - 12, "=== INSTRUCCIONES ===");
    attroff(COLOR_PAIR(CP_GOAL) | A_BOLD);
    r++;

    attron(COLOR_PAIR(CP_HUD) | A_BOLD);
    mvprintw(r++, 4, "OBJETIVO:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "Asciende la montana rompiendo bloques [y],");
    mvprintw(r++, 4, "usando plataformas ~~~~~~~ y esquivando enemigos >O<.");
    mvprintw(r++, 4, "Llega a la meta ^^^META^^^ en 3 niveles para ganar!");
    attroff(COLOR_PAIR(CP_HUD));
    r++;

    attron(COLOR_PAIR(CP_PLAYER1) | A_BOLD);
    mvprintw(r++, 4, "JUGADOR 1 - Popo [P]:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  A = mover izquierda");
    mvprintw(r++, 4, "  D = mover derecha");
    mvprintw(r++, 4, "  W = saltar / golpear bloque hacia arriba");
    attroff(COLOR_PAIR(CP_PLAYER1));
    r++;

    attron(COLOR_PAIR(CP_PLAYER2) | A_BOLD);
    mvprintw(r++, 4, "JUGADOR 2 - Nana [N]:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  Flecha izquierda = mover izquierda");
    mvprintw(r++, 4, "  Flecha derecha   = mover derecha");
    mvprintw(r++, 4, "  Flecha arriba    = saltar / golpear");
    attroff(COLOR_PAIR(CP_PLAYER2));
    r++;

    attron(COLOR_PAIR(CP_HUD) | A_BOLD);
    mvprintw(r++, 4, "GLOBALES:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  P = Pausar / Reanudar");
    mvprintw(r++, 4, "  Q / ESC = Salir");
    attroff(COLOR_PAIR(CP_HUD));
    r++;

    attron(COLOR_PAIR(CP_BLOCK) | A_BOLD);
    mvprintw(r++, 4, "LEYENDA:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  [P] = Popo (J1)   [N] = Nana (J2)   >O< = Enemigo");
    mvprintw(r++, 4, "  [y] = Bloque (rompible)   [#] = Bloque indestructible");
    mvprintw(r++, 4, "  ~~~~~~~ = Plataforma movil    | = Carambano (Nv.3)");
    mvprintw(r++, 4, "  ^^^META^^^ = Meta / Cima del nivel");
    attroff(COLOR_PAIR(CP_BLOCK));
    r++;

    attron(COLOR_PAIR(CP_PLATFORM) | A_BOLD);
    mvprintw(r++, 4, "NIVELES:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  Nv.1: Facil - pocos enemigos, plataformas lentas");
    mvprintw(r++, 4, "  Nv.2: Medio - mas enemigos, bloques indestructibles");
    mvprintw(r++, 4, "  Nv.3: Dificil - enemigos rapidos + carambanos cayendo");
    attroff(COLOR_PAIR(CP_PLATFORM));
    r++;

    attron(COLOR_PAIR(CP_ENEMY) | A_BOLD);
    mvprintw(r++, 4, "PUNTUACION:");
    attroff(A_BOLD);
    mvprintw(r++, 4, "  Romper bloque: +10   Completar nivel: +100");
    mvprintw(r++, 4, "  Ganar el juego: +300 bonus");
    attroff(COLOR_PAIR(CP_ENEMY));
    r++;

    attron(COLOR_PAIR(CP_DEFAULT));
    mvprintw(r + 1, cx - 18, "Presiona cualquier tecla para volver al menu...");
    attroff(COLOR_PAIR(CP_DEFAULT));

    refresh();
    getch();
    nodelay(stdscr, TRUE);
}

// ─── Pantalla de puntajes altos ───────────────────────────────────────────────
void showHighScores(const std::string& scoresFile) {
    nodelay(stdscr, FALSE);
    erase();

    auto scores = loadScores(scoresFile);

    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    (void)maxY;
    int cx = maxX / 2;
    int r  = 3;

    attron(COLOR_PAIR(CP_GOAL) | A_BOLD);
    mvprintw(r++, cx - 12, "=== PUNTAJES DESTACADOS ===");
    attroff(COLOR_PAIR(CP_GOAL) | A_BOLD);
    r++;

    attron(COLOR_PAIR(CP_HUD) | A_BOLD);
    mvprintw(r++, cx - 20, "  #   Nombre           Puntaje    Nivel");
    mvprintw(r++, cx - 20, "  ─────────────────────────────────────");
    attroff(A_BOLD);

    for (int i = 0; i < (int)scores.size(); i++) {
        int cp = (i == 0) ? CP_GOAL : (i < 3 ? CP_PLATFORM : CP_DEFAULT);
        mvprintw(r++, cx - 20,
                 "  %-3d %-16s %-10d %d",
                 i + 1,
                 scores[i].name.c_str(),
                 scores[i].score,
                 scores[i].level);
        (void)cp;
    }
    attroff(COLOR_PAIR(CP_HUD));

    r += 2;
    attron(COLOR_PAIR(CP_DEFAULT));
    mvprintw(r, cx - 20, "  Presiona cualquier tecla para volver...");
    attroff(COLOR_PAIR(CP_DEFAULT));

    refresh();
    getch();
    nodelay(stdscr, TRUE);
}
