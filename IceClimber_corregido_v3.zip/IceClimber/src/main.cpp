#include "Game.h"
#include "Renderer.h"
#include "Input.h"
#include "Player.h"
#include "Enemy.h"
#include "Platform.h"
#include "Event.h"
#include "Menu.h"
#include "ScoreManager.h"
#include <cstdlib>
#include <ctime>
#include <unistd.h>
#include <string>

static const std::string SCORES_FILE = "scores.txt";

// ─── Estructura para manejar los hilos del juego ──────────────────────────────
struct GameThreads {
    pthread_t render;
    pthread_t input;
    pthread_t player1;
    pthread_t player2;
    pthread_t enemies;
    pthread_t platforms;
    pthread_t events;

    bool hasPlayer2   = false;
    bool renderLaunched   = false;
    bool inputLaunched    = false;
    bool p1Launched       = false;
    bool p2Launched       = false;
    bool enemiesLaunched  = false;
    bool platformsLaunched = false;
    bool eventsLaunched   = false;
};

// ─── Lanzar hilos del juego ───────────────────────────────────────────────────
static void launchThreads(GameState& gs, GameThreads& gt) {
    // Hilo de renderizado
    pthread_create(&gt.render, nullptr, renderThread, &gs);
    gt.renderLaunched = true;

    // Hilo de entrada
    pthread_create(&gt.input, nullptr, inputThread, &gs);
    gt.inputLaunched = true;

    // Hilos de jugadores (cada jugador es un hilo independiente)
    PlayerThreadArg* arg1 = new PlayerThreadArg{&gs, 0};
    pthread_create(&gt.player1, nullptr, playerThread, arg1);
    gt.p1Launched = true;

    if (gs.numPlayers == 2) {
        PlayerThreadArg* arg2 = new PlayerThreadArg{&gs, 1};
        pthread_create(&gt.player2, nullptr, playerThread, arg2);
        gt.p2Launched  = true;
        gt.hasPlayer2  = true;
    }

    // Hilo de enemigos (administrador único para todos los enemigos)
    pthread_create(&gt.enemies, nullptr, enemiesThread, &gs);
    gt.enemiesLaunched = true;

    // Hilo de plataformas
    pthread_create(&gt.platforms, nullptr, platformThread, &gs);
    gt.platformsLaunched = true;

    // Hilo de eventos globales
    pthread_create(&gt.events, nullptr, eventThread, &gs);
    gt.eventsLaunched = true;
}

// ─── Detener y unir hilos ─────────────────────────────────────────────────────
static void joinThreads(GameState& gs, GameThreads& gt) {
    // Asegurarse que running = false para que los hilos terminen
    gs.running.store(false);

    // Despertar al hilo de renderizado (puede estar bloqueado en sem_wait)
    sem_post(&gs.renderSem);

    // Despertar posibles hilos bloqueados en pauseSem
    sem_post(&gs.pauseSem);
    sem_post(&gs.pauseSem);

    if (gt.renderLaunched)    { pthread_join(gt.render,    nullptr); gt.renderLaunched    = false; }
    if (gt.inputLaunched)     { pthread_join(gt.input,     nullptr); gt.inputLaunched     = false; }
    if (gt.p1Launched)        { pthread_join(gt.player1,   nullptr); gt.p1Launched        = false; }
    if (gt.p2Launched)        { pthread_join(gt.player2,   nullptr); gt.p2Launched        = false; }
    if (gt.enemiesLaunched)   { pthread_join(gt.enemies,   nullptr); gt.enemiesLaunched   = false; }
    if (gt.platformsLaunched) { pthread_join(gt.platforms, nullptr); gt.platformsLaunched = false; }
    if (gt.eventsLaunched)    { pthread_join(gt.events,    nullptr); gt.eventsLaunched    = false; }

    gt.hasPlayer2 = false;
}

// ─── Inicializar GameState ────────────────────────────────────────────────────
static void initGameState(GameState& gs, int numPlayers) {
    gs.numPlayers = numPlayers;
    gs.running.store(false);
    gs.paused.store(false);
    gs.gameOver.store(false);
    gs.levelComplete.store(false);
    gs.gameWon.store(false);
    gs.changingLevel.store(false);

    // Inicializar vidas del jugador por primera vez
    for (int i = 0; i < 2; i++) {
        gs.players[i].lives = 3;
        gs.players[i].score = 0;
        gs.players[i].id    = i;
    }

    // Inicializar mutex y semáforos
    pthread_mutex_init(&gs.mutex, nullptr);
    // renderSem inicia en 0: el render espera hasta que alguien haga post
    sem_init(&gs.renderSem, 0, 0);
    // pauseSem inicia en 0: los hilos esperan aquí cuando hay pausa
    sem_init(&gs.pauseSem, 0, 0);
}

// ─── Destruir GameState ───────────────────────────────────────────────────────
static void destroyGameState(GameState& gs) {
    pthread_mutex_destroy(&gs.mutex);
    sem_destroy(&gs.renderSem);
    sem_destroy(&gs.pauseSem);
}

// ─── Pantalla de transición entre niveles ─────────────────────────────────────
static void levelTransition(GameState& gs, int nextLevel) {
    drawLevelComplete(gs, nextLevel);
    usleep(2500000);  // 2.5 segundos para que el jugador lo vea
}

// ─── Loop principal del juego ─────────────────────────────────────────────────
// Retorna true si el jugador quiere reiniciar, false para ir al menú/salir
static bool runGame(int numPlayers) {
    GameState gs;
    initGameState(gs, numPlayers);
    loadLevel(gs, 1);

    GameThreads gt;
    gs.running.store(true);
    launchThreads(gs, gt);

    bool shouldRestart = false;
    bool shouldMenu    = false;

    // ── Loop principal: espera eventos de nivel y game over ────────────────
    while (gs.running.load()) {
        usleep(100000);  // chequear cada 100ms

        // ── Completar nivel ────────────────────────────────────────────────
        if (gs.levelComplete.load() && !gs.changingLevel.load()) {
            int nextLevel = gs.currentLevel + 1;

            gs.changingLevel.store(true);
            gs.levelComplete.store(false);

            // Añadir bonus de completar nivel
            pthread_mutex_lock(&gs.mutex);
            gs.players[0].score += 100;
            if (numPlayers == 2) gs.players[1].score += 100;
            pthread_mutex_unlock(&gs.mutex);

            if (nextLevel > 3) {
                // ¡Ganó el juego!
                pthread_mutex_lock(&gs.mutex);
                gs.players[0].score += 300;  // bonus final
                if (numPlayers == 2) gs.players[1].score += 300;
                gs.gameWon.store(true);
                pthread_mutex_unlock(&gs.mutex);

                levelTransition(gs, 4);
                gs.running.store(false);
                break;
            } else {
                levelTransition(gs, nextLevel);

                // Recargar nivel manteniendo vidas y puntaje acumulado
                int lives0 = gs.players[0].lives;
                int score0 = gs.players[0].score;
                int lives1 = gs.players[1].lives;
                int score1 = gs.players[1].score;

                pthread_mutex_lock(&gs.mutex);
                loadLevel(gs, nextLevel);
                gs.players[0].lives = lives0;
                gs.players[0].score = score0;
                if (numPlayers == 2) {
                    gs.players[1].lives = lives1;
                    gs.players[1].score = score1;
                }
                pthread_mutex_unlock(&gs.mutex);

                gs.changingLevel.store(false);
                // Señalizar render después de cambio de nivel
                sem_post(&gs.renderSem);
            }
        }

        // ── Verificar quit desde input ─────────────────────────────────────
        pthread_mutex_lock(&gs.mutex);
        bool wantQuit    = gInput.quit;
        bool wantRestart = gInput.restart;
        bool wantMenu    = gInput.goMenu;
        pthread_mutex_unlock(&gs.mutex);

        if (wantQuit)    { gs.running.store(false); break; }
        if (wantRestart) { shouldRestart = true; gs.running.store(false); break; }
        if (wantMenu)    { shouldMenu    = true; gs.running.store(false); break; }
    }

    // ── Detener todos los hilos ────────────────────────────────────────────
    joinThreads(gs, gt);

    // ── Guardar puntaje si la partida terminó ──────────────────────────────
    if (gs.gameOver.load() || gs.gameWon.load()) {
        int totalScore = gs.players[0].score + (numPlayers == 2 ? gs.players[1].score : 0);
        std::string name = (numPlayers == 2) ? "Popo+Nana" : "Popo";
        saveScore(SCORES_FILE, name, totalScore, gs.currentLevel);

        // Mostrar pantalla final
        drawEndScreen(gs);
        nodelay(stdscr, FALSE);

        // Esperar decision del jugador
        while (true) {
            int ch = getch();
            if (ch == 'r' || ch == 'R') { shouldRestart = true; break; }
            if (ch == 'm' || ch == 'M') { shouldMenu    = true; break; }
            if (ch == 'q' || ch == 'Q' || ch == 27) break;
        }
        nodelay(stdscr, TRUE);
    }

    destroyGameState(gs);

    if (shouldRestart) return true;   // reiniciar con mismo modo
    return false;
}

// ─── main ─────────────────────────────────────────────────────────────────────
int main() {
    srand((unsigned)time(nullptr));

    setupNCurses();

    // ── Verificar tamaño mínimo de terminal ────────────────────────────────
    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    if (maxX < BOARD_W + 2 || maxY < BOARD_H + HUD_ROWS + 2) {
        endwin();
        printf("Error: Terminal muy pequena.\n");
        printf("Aumente el tamano de la terminal a minimo %d columnas x %d filas.\n",
               BOARD_W + 2, BOARD_H + HUD_ROWS + 2);
        return 1;
    }

    bool exitApp = false;

    while (!exitApp) {
        // Limpiar flags de input antes de cada sesión
        gInput = {};

        MenuResult result = showMainMenu();

        switch (result) {
            case MenuResult::PLAY_1P: {
                int numPlayers = 1;
                bool restart   = true;
                while (restart) {
                    gInput = {};
                    restart = runGame(numPlayers);
                }
                break;
            }
            case MenuResult::PLAY_2P: {
                int numPlayers = 2;
                bool restart   = true;
                while (restart) {
                    gInput = {};
                    restart = runGame(numPlayers);
                }
                break;
            }
            case MenuResult::INSTRUCTIONS:
                showInstructions();
                break;
            case MenuResult::HIGH_SCORES:
                showHighScores(SCORES_FILE);
                break;
            case MenuResult::EXIT:
                exitApp = true;
                break;
        }
    }

    endwin();
    return 0;
}
