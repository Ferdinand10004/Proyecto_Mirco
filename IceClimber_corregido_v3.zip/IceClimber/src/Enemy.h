#pragma once
#include "Game.h"

// Hilo administrador de enemigos: mueve todos los enemigos de forma autónoma
void* enemiesThread(void* arg);
