#pragma once
#include "Game.h"

// Resultado del menú principal
enum class MenuResult {
    PLAY_1P,
    PLAY_2P,
    INSTRUCTIONS,
    HIGH_SCORES,
    EXIT
};

// Mostrar menú principal; retorna la opción seleccionada
MenuResult showMainMenu();

// Pantalla de instrucciones
void showInstructions();

// Pantalla de puntajes
void showHighScores(const std::string& scoresFile);
