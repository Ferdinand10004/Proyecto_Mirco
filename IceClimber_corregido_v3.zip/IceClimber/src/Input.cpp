#include "Input.h"
#include <unistd.h>

// Flags de teclado globales compartidas
InputFlags gInput = {};

// ─── Hilo de entrada ──────────────────────────────────────────────────────────
// Lee teclas de forma no bloqueante y actualiza flags de input.
// IMPORTANTE: ncurses no es seguro entre hilos si getch() y mvprintw()/refresh()
// se ejecutan al mismo tiempo. Por eso este hilo también usa gs->mutex antes de
// llamar getch(). Esto evita que las secuencias internas de ncurses se mezclen y
// aparezcan residuos como "40m", "31;H", "7m", etc.
void* inputThread(void* arg) {
    GameState* gs = static_cast<GameState*>(arg);

    int p1LeftHold = 0, p1RightHold = 0;
    int p2LeftHold = 0, p2RightHold = 0;
    const int HOLD_TICKS = 7; // 7 * 8 ms ≈ 56 ms de movimiento por pulsación

    while (gs->running.load()) {
        int ch;
        bool readAny = false;

        pthread_mutex_lock(&gs->mutex);

        // Leer todas las teclas disponibles para no dejar cola acumulada.
        // Esta sección queda protegida por el mismo mutex que usa Renderer.cpp.
        while ((ch = getch()) != ERR) {
            readAny = true;

            switch (ch) {
                // ── Jugador 1 ─────────────────────────────────────────────
                case 'a': case 'A':
                    p1LeftHold = HOLD_TICKS;
                    p1RightHold = 0;
                    gInput.p1Left = true;
                    gInput.p1Right = false;
                    break;
                case 'd': case 'D':
                    p1RightHold = HOLD_TICKS;
                    p1LeftHold = 0;
                    gInput.p1Right = true;
                    gInput.p1Left = false;
                    break;
                case 'w': case 'W':
                    gInput.p1Jump = true;
                    break;

                // ── Jugador 2 ─────────────────────────────────────────────
                case KEY_LEFT:
                    p2LeftHold = HOLD_TICKS;
                    p2RightHold = 0;
                    gInput.p2Left = true;
                    gInput.p2Right = false;
                    break;
                case KEY_RIGHT:
                    p2RightHold = HOLD_TICKS;
                    p2LeftHold = 0;
                    gInput.p2Right = true;
                    gInput.p2Left = false;
                    break;
                case KEY_UP:
                    gInput.p2Jump = true;
                    break;

                // ── Globales ──────────────────────────────────────────────
                case 'p': case 'P':
                    gs->paused.store(!gs->paused.load());
                    if (!gs->paused.load()) {
                        sem_post(&gs->pauseSem);
                        sem_post(&gs->pauseSem);
                    }
                    readAny = true;
                    break;

                case 'q': case 'Q': case 27:
                    gInput.quit = true;
                    gs->running.store(false);
                    break;

                case 'r': case 'R':
                    gInput.restart = true;
                    break;

                case 'm': case 'M':
                    gInput.goMenu = true;
                    break;
            }
        }

        // Reducir contadores de movimiento. Así una pulsación genera varios
        // frames de movimiento y mantener presionada una tecla se siente fluido.
        if (p1LeftHold > 0)  p1LeftHold--;  else gInput.p1Left = false;
        if (p1RightHold > 0) p1RightHold--; else gInput.p1Right = false;
        if (p2LeftHold > 0)  p2LeftHold--;  else gInput.p2Left = false;
        if (p2RightHold > 0) p2RightHold--; else gInput.p2Right = false;

        pthread_mutex_unlock(&gs->mutex);

        if (readAny) sem_post(&gs->renderSem);
        usleep(8000); // polling rápido ≈125 Hz
    }
    return nullptr;
}
