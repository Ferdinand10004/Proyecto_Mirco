#include "Renderer.h"
#include <cstring>
#include <string>

// ─── Helpers ──────────────────────────────────────────────────────────────────
// Dibuja un string en coordenadas del tablero (relativas al offset)
static void boardPrint(GameState& gs, int row, int col, const char* str, int colorPair) {
    // Coordenadas relativas al tablero. Esta función evita imprimir fuera del
    // área jugable o fuera de la terminal, lo cual era la causa de residuos
    // visuales como 7m, 59H, 0m, etc.
    if (str == nullptr) return;
    if (row < 0 || row >= BOARD_H) return;
    if (col < 0 || col >= BOARD_W) return;

    int absY = gs.offsetY + HUD_ROWS + row;
    int absX = gs.offsetX + col;

    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    if (absY < 0 || absY >= maxY || absX < 0 || absX >= maxX) return;

    int maxLenBoard = BOARD_W - col;
    int maxLenTerm  = maxX - absX;
    int maxLen = (maxLenBoard < maxLenTerm) ? maxLenBoard : maxLenTerm;
    if (maxLen <= 0) return;

    attron(COLOR_PAIR(colorPair));
    mvaddnstr(absY, absX, str, maxLen);
    attroff(COLOR_PAIR(colorPair));
}

static void boardPrintChar(GameState& gs, int row, int col, char ch, int colorPair) {
    char buf[2] = {ch, '\0'};
    boardPrint(gs, row, col, buf, colorPair);
}

// ─── Dibujar HUD ──────────────────────────────────────────────────────────────
static void drawHUD(GameState& gs) {
    int absY  = gs.offsetY;
    int absX  = gs.offsetX;
    int width = BOARD_W;

    attron(COLOR_PAIR(CP_HUD));

    // Línea 0: título + nivel
    char line0[128];
    snprintf(line0, sizeof(line0), " ICE CLIMBER  |  Nivel: %d  |  %s",
             gs.currentLevel, gs.paused.load() ? "[ PAUSA ]" : "         ");
    mvprintw(absY, absX, "%-*s", width, line0);

    // Línea 1: jugador 1
    char line1[128];
    snprintf(line1, sizeof(line1), " P1[Popo] Vidas:%d  Score:%d",
             gs.players[0].lives, gs.players[0].score);
    if (gs.numPlayers == 2) {
        char p2[64];
        snprintf(p2, sizeof(p2), "   |   P2[Nana] Vidas:%d  Score:%d",
                 gs.players[1].lives, gs.players[1].score);
        strncat(line1, p2, sizeof(line1) - strlen(line1) - 1);
    }
    mvprintw(absY + 1, absX, "%-*s", width, line1);

    // Línea 2: controles rápidos
    char line2[128];
    snprintf(line2, sizeof(line2),
             " W/A/D=P1  Flechas=P2  P=Pausa  Q/ESC=Salir");
    mvprintw(absY + 2, absX, "%-*s", width, line2);

    attroff(COLOR_PAIR(CP_HUD));
}

// ─── Dibujar bordes del tablero ───────────────────────────────────────────────
static void drawBorders(GameState& gs) {
    // Borde superior
    attron(COLOR_PAIR(CP_WALL));
    for (int c = 0; c < BOARD_W; c++)
        boardPrintChar(gs, 0, c, '=', CP_WALL);
    // Borde inferior
    for (int c = 0; c < BOARD_W; c++)
        boardPrintChar(gs, BOARD_H - 1, c, '=', CP_WALL);
    // Bordes laterales
    for (int r = 1; r < BOARD_H - 1; r++) {
        boardPrintChar(gs, r, 0, '|', CP_WALL);
        boardPrintChar(gs, r, BOARD_W - 1, '|', CP_WALL);
    }
    attroff(COLOR_PAIR(CP_WALL));
}

// ─── Dibujar meta ─────────────────────────────────────────────────────────────
static void drawGoal(GameState& gs) {
    int gx = (BOARD_W - (int)strlen(SPR_GOAL)) / 2;
    boardPrint(gs, gs.goalY, gx, SPR_GOAL, CP_GOAL);
}

// ─── Dibujar bloques ──────────────────────────────────────────────────────────
static void drawBlocks(GameState& gs) {
    for (auto& b : gs.blocks) {
        if (b.destroyed) continue;
        const char* spr = b.destructible ? SPR_BLOCK : SPR_INDESTR;
        int cp = b.destructible ? CP_BLOCK : CP_WALL;
        boardPrint(gs, b.y, b.x, spr, cp);
    }
}

// ─── Dibujar plataformas ──────────────────────────────────────────────────────
static void drawPlatforms(GameState& gs) {
    for (auto& p : gs.platforms) {
        if (!p.active) continue;
        boardPrint(gs, p.y, p.x, SPR_PLATFORM, CP_PLATFORM);
    }
}

// ─── Dibujar enemigos ─────────────────────────────────────────────────────────
static void drawEnemies(GameState& gs) {
    for (auto& e : gs.enemies) {
        if (!e.active) continue;
        boardPrint(gs, e.y, e.x, SPR_ENEMY, CP_ENEMY);
    }
}

// ─── Dibujar carámbanos ───────────────────────────────────────────────────────
static void drawIcicles(GameState& gs) {
    for (auto& ic : gs.icicles) {
        if (!ic.active) continue;
        boardPrint(gs, ic.y, ic.x, SPR_ICICLE, CP_DANGER);
    }
}

// ─── Dibujar jugadores ────────────────────────────────────────────────────────
static void drawPlayers(GameState& gs) {
    for (int i = 0; i < gs.numPlayers; i++) {
        Player& p = gs.players[i];
        if (!p.alive) continue;
        // Parpadeo si fue golpeado recientemente
        if (p.recentlyHit && (p.hitTimer / 3) % 2 == 0) continue;
        const char* spr = (i == 0) ? SPR_PLAYER1 : SPR_PLAYER2;
        int cp = (i == 0) ? CP_PLAYER1 : CP_PLAYER2;
        boardPrint(gs, p.y, p.x, spr, cp);
    }
}

// ─── Hilo de renderizado ──────────────────────────────────────────────────────
void* renderThread(void* arg) {
    GameState* gs = static_cast<GameState*>(arg);

    while (gs->running.load()) {
        // Esperar señal de que hay algo que renderizar (el eventThread hace post)
        // sem_wait bloquea hasta que otro hilo llame sem_post(&gs->renderSem)
        sem_wait(&gs->renderSem);

        if (!gs->running.load()) break;

        // Adquirir mutex para dibujar de forma exclusiva
        pthread_mutex_lock(&gs->mutex);

        // Verificar tamaño de terminal
        if (!checkTermSize()) {
            erase();
            int maxY, maxX;
            getmaxyx(stdscr, maxY, maxX);
            attron(COLOR_PAIR(CP_ENEMY));
            mvprintw(maxY / 2, 2, "Aumente el tamano de la terminal (min %dx%d)",
                     BOARD_W + 2, BOARD_H + HUD_ROWS + 2);
            attroff(COLOR_PAIR(CP_ENEMY));
            refresh();
            pthread_mutex_unlock(&gs->mutex);
            continue;
        }

        calcOffset(*gs);
        erase();

        drawHUD(*gs);
        drawBorders(*gs);
        drawGoal(*gs);
        drawBlocks(*gs);
        drawPlatforms(*gs);
        drawEnemies(*gs);
        drawIcicles(*gs);
        drawPlayers(*gs);

        refresh();
        pthread_mutex_unlock(&gs->mutex);
    }
    return nullptr;
}

// ─── Pantalla de nivel completado ─────────────────────────────────────────────
void drawLevelComplete(GameState& gs, int nextLevel) {
    pthread_mutex_lock(&gs.mutex);
    calcOffset(gs);
    erase();

    int cy = gs.offsetY + (BOARD_H + HUD_ROWS) / 2;
    int cx = gs.offsetX + BOARD_W / 2;

    attron(COLOR_PAIR(CP_GOAL) | A_BOLD);
    mvprintw(cy - 2, cx - 12, "  *** NIVEL COMPLETADO! ***  ");
    attroff(COLOR_PAIR(CP_GOAL) | A_BOLD);

    attron(COLOR_PAIR(CP_HUD));
    if (nextLevel <= 3) {
        mvprintw(cy, cx - 14, "  Preparando Nivel %d...              ", nextLevel);
    } else {
        mvprintw(cy, cx - 14, "  !!! HAS GANADO EL JUEGO !!!        ");
    }
    attroff(COLOR_PAIR(CP_HUD));

    refresh();
    pthread_mutex_unlock(&gs.mutex);
}

// ─── Pantalla de fin de partida ───────────────────────────────────────────────
void drawEndScreen(GameState& gs) {
    pthread_mutex_lock(&gs.mutex);
    calcOffset(gs);
    erase();

    int cy = gs.offsetY + (BOARD_H + HUD_ROWS) / 2;
    int cx = gs.offsetX + BOARD_W / 2;

    if (gs.gameWon.load()) {
        attron(COLOR_PAIR(CP_GOAL) | A_BOLD);
        mvprintw(cy - 3, cx - 16, "  +------------------------------+  ");
        mvprintw(cy - 2, cx - 16, "  |   *** GANASTE EL JUEGO ***   |  ");
        mvprintw(cy - 1, cx - 16, "  +------------------------------+  ");
        attroff(COLOR_PAIR(CP_GOAL) | A_BOLD);
    } else {
        attron(COLOR_PAIR(CP_ENEMY) | A_BOLD);
        mvprintw(cy - 3, cx - 16, "  +------------------------------+  ");
        mvprintw(cy - 2, cx - 16, "  |        *** GAME OVER ***     |  ");
        mvprintw(cy - 1, cx - 16, "  +------------------------------+  ");
        attroff(COLOR_PAIR(CP_ENEMY) | A_BOLD);
    }

    attron(COLOR_PAIR(CP_HUD));
    int totalScore = gs.players[0].score + (gs.numPlayers == 2 ? gs.players[1].score : 0);
    mvprintw(cy + 1, cx - 16, "  Puntaje Total: %-6d                ", totalScore);
    mvprintw(cy + 3, cx - 16, "  [R] Reiniciar   [M] Menu   [Q] Salir");
    attroff(COLOR_PAIR(CP_HUD));

    refresh();
    pthread_mutex_unlock(&gs.mutex);
}
