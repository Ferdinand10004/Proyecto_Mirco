#include "Platform.h"
#include <unistd.h>

// ─── Hilo de plataformas móviles ─────────────────────────────────────────────
// Mueve todas las plataformas horizontalmente de forma autónoma.
// Se invierten al llegar a los bordes del tablero.
void* platformThread(void* arg) {
    GameState* gs = static_cast<GameState*>(arg);

    while (gs->running.load()) {
        if (gs->paused.load() || gs->changingLevel.load() || gs->gameOver.load()) {
            usleep(50000);
            continue;
        }

        pthread_mutex_lock(&gs->mutex);

        for (auto& p : gs->platforms) {
            if (!p.active) continue;

            p.x += p.dir;

            // Rebotar en los bordes
            if (p.x <= 1) {
                p.x   = 1;
                p.dir = 1;
            } else if (p.x + PLATFORM_LEN >= BOARD_W - 1) {
                p.x   = BOARD_W - 1 - PLATFORM_LEN;
                p.dir = -1;
            }
        }

        pthread_mutex_unlock(&gs->mutex);

        // Señalizar render
        sem_post(&gs->renderSem);

        // Velocidad controlada por config del nivel
        usleep((unsigned int)gs->levelCfg.platformSpeedMs * 1000);
    }
    return nullptr;
}
