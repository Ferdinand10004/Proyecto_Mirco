#pragma once
#include "Game.h"

// Hilo de renderizado: dibuja el estado del juego en tiempo real
void* renderThread(void* arg);

// Dibujar pantalla de "nivel completado"
void drawLevelComplete(GameState& gs, int nextLevel);

// Dibujar pantalla de Game Over / Victoria
void drawEndScreen(GameState& gs);
