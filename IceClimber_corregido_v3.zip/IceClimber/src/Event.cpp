#include "Event.h"
#include <unistd.h>
#include <cstdlib>

static bool icicleHitsPlayer(const Icicle& ic, const Player& p) {
    if (!ic.active || !p.alive || p.recentlyHit) return false;
    bool xOverlap = (p.x < ic.x + 1) && (p.x + PLAYER_LEN > ic.x);
    bool yOverlap = (ic.y >= p.y && ic.y <= p.y + 1);
    return xOverlap && yOverlap;
}

static void damagePlayerFromIcicle(GameState* gs, Player& p) {
    p.lives--;
    if (p.lives <= 0) {
        p.alive = false;
        return;
    }

    // Respawn seguro + invulnerabilidad breve para no perder varias vidas seguidas.
    p.x = p.spawnX;
    p.y = p.spawnY;
    p.velY = 0;
    p.jumping = false;
    p.onGround = true;
    p.onPlatform = false;
    p.platformIdx = -1;
    p.recentlyHit = true;
    p.hitTimer = 45;
}

static void resetIcicle(Icicle& ic) {
    ic.y = 1;
    ic.x = 2 + rand() % (BOARD_W - 6);
}

// ─── Hilo de eventos globales ─────────────────────────────────────────────────
// Este hilo verifica periódicamente:
//  1. Si todos los jugadores perdieron todas sus vidas → Game Over
//  2. Si se completó el nivel → marcar levelComplete (ya lo hacen los hilos de jugador)
//  3. Mover carámbanos cayendo (nivel 3)
// También hace sem_post al renderSem para forzar actualizaciones de pantalla.
void* eventThread(void* arg) {
    GameState* gs = static_cast<GameState*>(arg);

    while (gs->running.load()) {
        if (gs->changingLevel.load()) {
            usleep(50000);
            continue;
        }

        // Pequeña pausa entre verificaciones
        usleep(100000);  // 100 ms

        pthread_mutex_lock(&gs->mutex);

        // ── Verificar Game Over ────────────────────────────────────────────
        if (!gs->gameOver.load()) {
            bool allDead = true;
            for (int i = 0; i < gs->numPlayers; i++) {
                if (gs->players[i].alive && gs->players[i].lives > 0)
                    allDead = false;
            }
            if (allDead) {
                gs->gameOver.store(true);
                gs->running.store(false);
            }
        }

        // ── Carámbanos cayendo (Nivel 3) ───────────────────────────────────
        if (gs->levelCfg.hasFallingIcicles && gs->running.load()) {
            for (auto& ic : gs->icicles) {
                if (!ic.active) continue;

                ic.y++;

                // Chocar con jugador → quitar una vida, reaparecer jugador y reiniciar carámbano.
                bool hitPlayer = false;
                for (int i = 0; i < gs->numPlayers; i++) {
                    Player& p = gs->players[i];
                    if (icicleHitsPlayer(ic, p)) {
                        damagePlayerFromIcicle(gs, p);
                        hitPlayer = true;
                        break;
                    }
                }
                if (hitPlayer) {
                    resetIcicle(ic);
                    continue;
                }

                // Chocar con suelo → reaparecer arriba
                if (ic.y >= BOARD_H - 2) {
                    resetIcicle(ic);
                    continue;
                }

                // Chocar con bloque → destruirlo y reaparecer arriba
                for (auto& b : gs->blocks) {
                    if (!b.destroyed && b.destructible &&
                        abs(ic.x - b.x) <= 2 && ic.y == b.y) {
                        b.destroyed = true;
                        resetIcicle(ic);
                        break;
                    }
                }
            }
        }

        pthread_mutex_unlock(&gs->mutex);

        // Señalizar render para que se actualice la pantalla
        sem_post(&gs->renderSem);
    }
    return nullptr;
}
