#include "Player.h"
#include "Input.h"
#include <unistd.h>
#include <cstdlib>

// ─── Constantes de física ─────────────────────────────────────────────────────
// Valores más rápidos que la versión original. Con 80 ms por tick el input se
// sentía pesado; 30 ms permite corregir la posición en el aire.
static const int JUMP_VEL     = -5;   // salto moderado: permite subir escalones sin elevarse demasiado
static const int GRAVITY      = 1;    // gravedad: se suma a velY cada tick
static const int MAX_FALL     = 4;    // velocidad máxima de caída
static const int PHYSICS_MS   = 30;   // ms por tick de física
static const int H_SPEED      = 2;    // movimiento horizontal por tick

// ─── Utilidades de colisión ───────────────────────────────────────────────────
static bool overlapX(int ax, int aw, int bx, int bw) {
    return (ax < bx + bw) && (ax + aw > bx);
}

// Bloque sólido en la misma fila del jugador. Se usa para bloquear movimiento
// horizontal antes de cambiar x. Esto evita que [P] o [N] atraviesen [y]/[#].
static bool collidesSolidBlockAt(GameState& gs, int px, int py, int& blockIdx) {
    for (int i = 0; i < (int)gs.blocks.size(); i++) {
        Block& b = gs.blocks[i];
        if (b.destroyed) continue;
        bool xOverlap = overlapX(px, PLAYER_LEN, b.x, BLOCK_LEN);
        bool yOverlap = (py == b.y);
        if (xOverlap && yOverlap) {
            blockIdx = i;
            return true;
        }
    }
    blockIdx = -1;
    return false;
}

// ─── Detectar colisión con bloques (AABB) ────────────────────────────────────
// checkAbove = true: verifica golpe desde abajo mientras el jugador sube.
// checkAbove = false: verifica aterrizaje sobre un bloque mientras cae.
bool collidesWithBlock(GameState& gs, int px, int py, int& blockIdx, bool checkAbove) {
    for (int i = 0; i < (int)gs.blocks.size(); i++) {
        Block& b = gs.blocks[i];
        if (b.destroyed) continue;

        bool xOverlap = overlapX(px, PLAYER_LEN, b.x, BLOCK_LEN);
        if (!xOverlap) continue;

        if (checkAbove) {
            if (py <= b.y && py >= b.y - 1) {
                blockIdx = i;
                return true;
            }
        } else {
            if (py + 1 >= b.y && py <= b.y) {
                blockIdx = i;
                return true;
            }
        }
    }
    blockIdx = -1;
    return false;
}

// Aterrizaje robusto: revisa si entre oldY y newY los pies cruzaron el bloque.
static bool landedOnBlock(GameState& gs, int px, int oldY, int newY, int& blockIdx) {
    for (int i = 0; i < (int)gs.blocks.size(); i++) {
        Block& b = gs.blocks[i];
        if (b.destroyed) continue;
        if (!overlapX(px, PLAYER_LEN, b.x, BLOCK_LEN)) continue;

        int oldFeet = oldY + 1;
        int newFeet = newY + 1;
        if (oldFeet <= b.y && newFeet >= b.y) {
            blockIdx = i;
            return true;
        }
    }
    blockIdx = -1;
    return false;
}

// Golpe robusto desde abajo: revisa si entre oldY y newY la cabeza cruzó el bloque.
static bool hitBlockFromBelow(GameState& gs, int px, int oldY, int newY, int& blockIdx) {
    for (int i = 0; i < (int)gs.blocks.size(); i++) {
        Block& b = gs.blocks[i];
        if (b.destroyed) continue;
        if (!overlapX(px, PLAYER_LEN, b.x, BLOCK_LEN)) continue;

        if (oldY >= b.y + 1 && newY <= b.y) {
            blockIdx = i;
            return true;
        }
    }
    blockIdx = -1;
    return false;
}

// ─── Detectar colisión con plataformas ───────────────────────────────────────
bool collidesWithPlatform(GameState& gs, int px, int py, int& platIdx) {
    for (int i = 0; i < (int)gs.platforms.size(); i++) {
        Platform& p = gs.platforms[i];
        if (!p.active) continue;

        bool xOverlap = overlapX(px, PLAYER_LEN, p.x, PLATFORM_LEN);
        if (xOverlap && py + 1 == p.y) {
            platIdx = i;
            return true;
        }
    }
    platIdx = -1;
    return false;
}

static bool landedOnPlatform(GameState& gs, int px, int oldY, int newY, int& platIdx) {
    for (int i = 0; i < (int)gs.platforms.size(); i++) {
        Platform& p = gs.platforms[i];
        if (!p.active) continue;
        if (!overlapX(px, PLAYER_LEN, p.x, PLATFORM_LEN)) continue;
        int oldFeet = oldY + 1;
        int newFeet = newY + 1;
        if (oldFeet <= p.y && newFeet >= p.y) {
            platIdx = i;
            return true;
        }
    }
    platIdx = -1;
    return false;
}

// ─── Detectar colisión con enemigos ──────────────────────────────────────────
static bool collidesWithEnemy(GameState& gs, int px, int py) {
    for (auto& e : gs.enemies) {
        if (!e.active) continue;
        bool xOverlap = overlapX(px, PLAYER_LEN, e.x, ENEMY_LEN);
        bool yOverlap = (py == e.y);
        if (xOverlap && yOverlap) return true;
    }
    return false;
}

// ─── Detectar colisión con carámbanos ────────────────────────────────────────
static bool collidesWithIcicle(GameState& gs, int px, int py) {
    for (auto& ic : gs.icicles) {
        if (!ic.active) continue;
        // AABB simple: el jugador ocupa PLAYER_LEN columnas y una fila visible.
        bool xOverlap = overlapX(px, PLAYER_LEN, ic.x, 1);
        bool yOverlap = (ic.y >= py && ic.y <= py + 1);
        if (xOverlap && yOverlap) return true;
    }
    return false;
}

// ─── Respawn del jugador ──────────────────────────────────────────────────────
static void respawnPlayer(GameState& gs, Player& p) {
    p.x           = p.spawnX;
    p.y           = p.spawnY;
    p.velY        = 0;
    p.jumping     = false;
    p.onGround    = true;
    p.onPlatform  = false;
    p.platformIdx = -1;
    p.recentlyHit = true;
    p.hitTimer    = 30;
}

// ─── Hilo de jugador ──────────────────────────────────────────────────────────
void* playerThread(void* arg) {
    PlayerThreadArg* pArg = static_cast<PlayerThreadArg*>(arg);
    GameState* gs  = pArg->gs;
    int        idx = pArg->playerIdx;

    while (gs->running.load()) {
        if (gs->paused.load() || gs->changingLevel.load() || gs->gameOver.load()) {
            usleep(20000);
            continue;
        }

        pthread_mutex_lock(&gs->mutex);

        Player& p = gs->players[idx];

        if (!p.alive) {
            pthread_mutex_unlock(&gs->mutex);
            usleep(PHYSICS_MS * 1000);
            continue;
        }

        if (p.recentlyHit) {
            p.hitTimer--;
            if (p.hitTimer <= 0) p.recentlyHit = false;
        }

        bool doLeft  = (idx == 0) ? gInput.p1Left  : gInput.p2Left;
        bool doRight = (idx == 0) ? gInput.p1Right : gInput.p2Right;
        bool doJump  = (idx == 0) ? gInput.p1Jump  : gInput.p2Jump;

        if (idx == 0) gInput.p1Jump = false;
        else          gInput.p2Jump = false;

        // ── Movimiento horizontal con colisión lateral ────────────────────
        int nextX = p.x;
        if (doLeft)  nextX -= H_SPEED;
        if (doRight) nextX += H_SPEED;

        if (nextX < 1) nextX = 1;
        if (nextX + PLAYER_LEN > BOARD_W - 1) nextX = BOARD_W - 1 - PLAYER_LEN;

        int sideBlock;
        if (!collidesSolidBlockAt(*gs, nextX, p.y, sideBlock)) {
            p.x = nextX;
        }

        // ── Salto ──────────────────────────────────────────────────────────
        if (doJump && (p.onGround || p.onPlatform)) {
            p.velY      = JUMP_VEL;
            p.jumping   = true;
            p.onGround  = false;
            p.onPlatform = false;
            p.platformIdx = -1;
        }

        int oldY = p.y;

        // ── Física vertical ────────────────────────────────────────────────
        p.velY += GRAVITY;
        if (p.velY > MAX_FALL) p.velY = MAX_FALL;
        int newY = p.y + p.velY;

        if (newY <= 1) {
            newY = 1;
            p.velY = 0;
        }

        // ── Golpe desde abajo contra bloque ───────────────────────────────
        if (p.velY < 0) {
            int bIdx;
            if (hitBlockFromBelow(*gs, p.x, oldY, newY, bIdx)) {
                Block& b = gs->blocks[bIdx];
                if (b.destructible) {
                    b.destroyed = true;
                    p.score += 10;
                    // Se deja seguir subiendo un poco, como Ice Climber.
                    newY = b.y - 1;
                } else {
                    p.velY = 1;
                    newY = b.y + 1;
                }
            }
        }

        p.onGround = false;
        p.onPlatform = false;
        p.platformIdx = -1;

        // ── Aterrizaje en suelo ───────────────────────────────────────────
        if (newY >= BOARD_H - 2) {
            newY       = BOARD_H - 2;
            p.velY     = 0;
            p.onGround = true;
            p.jumping  = false;
        }

        // ── Aterrizaje en bloque ──────────────────────────────────────────
        if (p.velY > 0) {
            int bIdx;
            if (landedOnBlock(*gs, p.x, oldY, newY, bIdx)) {
                newY        = gs->blocks[bIdx].y - 1;
                p.velY      = 0;
                p.onGround  = true;
                p.jumping   = false;
            }
        }

        // ── Aterrizaje en plataforma ──────────────────────────────────────
        if (p.velY >= 0) {
            int pIdx;
            if (landedOnPlatform(*gs, p.x, oldY, newY, pIdx)) {
                newY          = gs->platforms[pIdx].y - 1;
                p.velY        = 0;
                p.onPlatform  = true;
                p.platformIdx = pIdx;
                p.jumping     = false;
                // Mover con la plataforma si no empuja contra bloque o borde.
                int carriedX = p.x + gs->platforms[pIdx].dir;
                if (carriedX < 1) carriedX = 1;
                if (carriedX + PLAYER_LEN > BOARD_W - 1)
                    carriedX = BOARD_W - 1 - PLAYER_LEN;
                int dummy;
                if (!collidesSolidBlockAt(*gs, carriedX, newY, dummy)) p.x = carriedX;
            }
        }

        p.y = newY;
        if (p.y < 1) p.y = 1;

        // Si quedó exactamente dentro de un bloque por algún borde raro, sacarlo arriba.
        int overlapBlock;
        if (collidesSolidBlockAt(*gs, p.x, p.y, overlapBlock)) {
            p.y = gs->blocks[overlapBlock].y - 1;
            p.velY = 0;
            p.onGround = true;
            p.jumping = false;
        }

        // ── Colisión con enemigos ──────────────────────────────────────────
        if (!p.recentlyHit && collidesWithEnemy(*gs, p.x, p.y)) {
            p.lives--;
            if (p.lives <= 0) {
                p.alive = false;
            } else {
                respawnPlayer(*gs, p);
            }
        }

        // ── Colisión con carámbanos ────────────────────────────────────────
        if (!p.recentlyHit && collidesWithIcicle(*gs, p.x, p.y)) {
            p.lives--;
            if (p.lives <= 0) p.alive = false;
            else respawnPlayer(*gs, p);
        }

        // ── Verificar si llegó a la meta ───────────────────────────────────
        if (p.y <= gs->goalY + 1 && !gs->levelComplete.load()) {
            gs->levelComplete.store(true);
            // El bonus de nivel se entrega en main.cpp una sola vez para evitar duplicarlo.
        }

        pthread_mutex_unlock(&gs->mutex);

        sem_post(&gs->renderSem);
        usleep(PHYSICS_MS * 1000);
    }

    delete pArg;
    return nullptr;
}
