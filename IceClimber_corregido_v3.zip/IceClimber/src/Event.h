#pragma once
#include "Game.h"

// Hilo de eventos globales: verifica Game Over, cambio de nivel,
// caída de carámbanos y otras condiciones del juego.
void* eventThread(void* arg);
