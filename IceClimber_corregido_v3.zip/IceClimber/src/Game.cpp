#include "Game.h"
#include <cstring>

// ─── Inicializar pares de colores ncurses ────────────────────────────────────
void initColors() {
    start_color();
    use_default_colors();
    init_pair(CP_DEFAULT,  COLOR_WHITE,   COLOR_BLACK);
    init_pair(CP_PLAYER1,  COLOR_GREEN,   COLOR_BLACK);
    init_pair(CP_PLAYER2,  COLOR_MAGENTA, COLOR_BLACK);
    init_pair(CP_ENEMY,    COLOR_RED,     COLOR_BLACK);
    init_pair(CP_BLOCK,    COLOR_CYAN,    COLOR_BLACK);
    init_pair(CP_PLATFORM, COLOR_YELLOW,  COLOR_BLACK);
    init_pair(CP_HUD,      COLOR_YELLOW,  COLOR_BLACK);
    init_pair(CP_WALL,     COLOR_WHITE,   COLOR_BLACK);
    init_pair(CP_GOAL,     COLOR_GREEN,   COLOR_BLACK);
    init_pair(CP_DANGER,   COLOR_RED,     COLOR_BLACK);
    init_pair(CP_MENU_SEL, COLOR_BLACK,   COLOR_YELLOW);
}

// ─── Configurar ncurses ───────────────────────────────────────────────────────
void setupNCurses() {
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    nodelay(stdscr, TRUE);
    curs_set(0);
    if (has_colors()) initColors();
}

// ─── Calcular offset para centrar tablero ─────────────────────────────────────
void calcOffset(GameState& gs) {
    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    gs.offsetX = (maxX - BOARD_W) / 2;
    gs.offsetY = (maxY - (BOARD_H + HUD_ROWS)) / 2;
    if (gs.offsetX < 0) gs.offsetX = 0;
    if (gs.offsetY < 0) gs.offsetY = 0;
}

// ─── Verificar tamaño de terminal ─────────────────────────────────────────────
bool checkTermSize() {
    int maxY, maxX;
    getmaxyx(stdscr, maxY, maxX);
    return (maxX >= BOARD_W + 2 && maxY >= BOARD_H + HUD_ROWS + 2);
}

// ─── Configuraciones por nivel ────────────────────────────────────────────────
static LevelConfig LEVELS[3] = {
    // Nivel 1: fácil
    { 3, 600, 700, 2, 55, false, false },
    // Nivel 2: medio
    { 5, 400, 500, 3, 65, false, true  },
    // Nivel 3: difícil
    { 7, 250, 300, 4, 70, true,  true  }
};

// ─── Generar bloques para un nivel ────────────────────────────────────────────
// Cada "piso" de bloques ocupa una fila a intervalos regulares.
// Se deja un hueco aleatorio en cada fila para que el jugador pase.
static void generateBlocks(GameState& gs) {
    gs.blocks.clear();
    const LevelConfig& cfg = gs.levelCfg;

    // Filas de bloques: de BOARD_H-3 subiendo cada 3 filas, hasta la meta+2
    // goalY = 2 (fila de la meta, debajo del HUD)
    // Pisos: desde fila 22 hasta fila 5, cada 3 filas → ~6 pisos
    for (int row = BOARD_H - 4; row >= 4; row -= 3) {
        // Columnas de bloques con huecos
        for (int col = 1; col < BOARD_W - 3; col += 3) {
            // Probabilidad de colocar bloque según densidad del nivel
            bool place = (rand() % 100) < cfg.blockDensity;
            if (!place) continue;

            // En nivel 2 y 3, algunos bloques son indestructibles
            bool indestr = false;
            if (cfg.hasIndestructibleBlocks && (rand() % 100) < 20) {
                indestr = true;
            }

            Block b;
            b.x = col;
            b.y = row;
            b.destructible = !indestr;
            b.destroyed = false;
            gs.blocks.push_back(b);
        }
    }
}

// ─── Generar plataformas para un nivel ────────────────────────────────────────
static void generatePlatforms(GameState& gs) {
    gs.platforms.clear();
    const LevelConfig& cfg = gs.levelCfg;

    // Posiciones fijas por nivel para garantizar jugabilidad
    int platformRows[4][4] = {
        { 18, 12, 0,  0  },  // Nivel 1 (2 plataformas)
        { 20, 14, 8,  0  },  // Nivel 2 (3 plataformas)
        { 21, 16, 10, 5  }   // Nivel 3 (4 plataformas)
    };
    int lvlIdx = gs.currentLevel - 1;

    for (int i = 0; i < cfg.platformCount; i++) {
        Platform p;
        p.y   = platformRows[lvlIdx][i];
        p.x   = (i % 2 == 0) ? 5 : BOARD_W - 5 - PLATFORM_LEN;
        p.dir = (i % 2 == 0) ? 1 : -1;
        p.active = true;
        gs.platforms.push_back(p);
    }
}

// ─── Generar enemigos para un nivel ──────────────────────────────────────────
static void generateEnemies(GameState& gs) {
    gs.enemies.clear();
    const LevelConfig& cfg = gs.levelCfg;

    // Distribuir enemigos en distintos pisos
    int enemyRows[] = { BOARD_H-5, BOARD_H-9, BOARD_H-13, BOARD_H-17, BOARD_H-20, BOARD_H-23, 4 };
    for (int i = 0; i < cfg.enemyCount; i++) {
        Enemy e;
        e.x       = 5 + (i * 10) % (BOARD_W - 10);
        e.y       = enemyRows[i % 7];
        e.dir     = (i % 2 == 0) ? 1 : -1;
        e.active  = true;
        e.floorY  = e.y;
        gs.enemies.push_back(e);
    }
}

// ─── Resetear jugadores a posición inicial ────────────────────────────────────
void resetPlayers(GameState& gs) {
    // Jugador 1 - Popo
    gs.players[0].x           = BOARD_W / 2 - 5;
    gs.players[0].y           = BOARD_H - 2;
    gs.players[0].velY        = 0;
    gs.players[0].jumping     = false;
    gs.players[0].onGround    = true;
    gs.players[0].onPlatform  = false;
    gs.players[0].platformIdx = -1;
    gs.players[0].alive       = true;
    gs.players[0].recentlyHit = false;
    gs.players[0].hitTimer    = 0;
    gs.players[0].spawnX      = gs.players[0].x;
    gs.players[0].spawnY      = gs.players[0].y;
    if (gs.numPlayers < 1) gs.players[0].lives = 3;

    if (gs.numPlayers == 2) {
        // Jugador 2 - Nana
        gs.players[1].x           = BOARD_W / 2 + 3;
        gs.players[1].y           = BOARD_H - 2;
        gs.players[1].velY        = 0;
        gs.players[1].jumping     = false;
        gs.players[1].onGround    = true;
        gs.players[1].onPlatform  = false;
        gs.players[1].platformIdx = -1;
        gs.players[1].alive       = true;
        gs.players[1].recentlyHit = false;
        gs.players[1].hitTimer    = 0;
        gs.players[1].spawnX      = gs.players[1].x;
        gs.players[1].spawnY      = gs.players[1].y;
        if (gs.numPlayers < 2) gs.players[1].lives = 3;
    }
}

// ─── Cargar nivel ─────────────────────────────────────────────────────────────
void loadLevel(GameState& gs, int level) {
    gs.currentLevel = level;
    gs.levelCfg     = LEVELS[level - 1];
    gs.goalY        = 2;   // la meta está en la fila 2 (debajo del borde superior)

    // Limpiar carámbanos
    gs.icicles.clear();

    generateBlocks(gs);
    generatePlatforms(gs);
    generateEnemies(gs);
    resetPlayers(gs);

    // Pre-generar carámbanos para nivel 3
    if (gs.levelCfg.hasFallingIcicles) {
        for (int i = 0; i < 4; i++) {
            Icicle ic;
            ic.x      = 5 + (i * 17) % (BOARD_W - 6);
            ic.y      = 0;
            ic.active = true;
            gs.icicles.push_back(ic);
        }
    }
}
