#pragma once
#include <string>
#include <vector>

struct ScoreEntry {
    std::string name;
    int         score;
    int         level;
};

// Cargar puntajes desde archivo
std::vector<ScoreEntry> loadScores(const std::string& filename);

// Guardar un nuevo puntaje
void saveScore(const std::string& filename, const std::string& name,
               int score, int level);
