#include "Enemy.h"
#include <unistd.h>

// ─── Hilo de enemigos ─────────────────────────────────────────────────────────
// Gestiona el movimiento autónomo de todos los enemigos.
// Los enemigos patrullan de izquierda a derecha en su fila.
void* enemiesThread(void* arg) {
    GameState* gs = static_cast<GameState*>(arg);

    while (gs->running.load()) {
        if (gs->paused.load() || gs->changingLevel.load() || gs->gameOver.load()) {
            usleep(50000);
            continue;
        }

        pthread_mutex_lock(&gs->mutex);

        for (auto& e : gs->enemies) {
            if (!e.active) continue;

            // Mover en dirección actual
            e.x += e.dir;

            // Rebotar en los bordes del tablero
            if (e.x <= 1) {
                e.x   = 1;
                e.dir = 1;
            } else if (e.x + ENEMY_LEN >= BOARD_W - 1) {
                e.x   = BOARD_W - 1 - ENEMY_LEN;
                e.dir = -1;
            }

            // Mantener al enemigo en su fila (gravedad simple)
            e.y = e.floorY;
        }

        pthread_mutex_unlock(&gs->mutex);

        // Señalizar render
        sem_post(&gs->renderSem);

        // Velocidad controlada por config del nivel
        usleep((unsigned int)gs->levelCfg.enemySpeedMs * 1000);
    }
    return nullptr;
}
