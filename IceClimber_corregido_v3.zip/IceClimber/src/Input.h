#pragma once
#include "Game.h"

// Flags de teclas compartidas (protegidas por mutex)
struct InputFlags {
    bool p1Left, p1Right, p1Jump;
    bool p2Left, p2Right, p2Jump;
    bool pause;
    bool quit;
    bool restart;
    bool goMenu;
};

extern InputFlags gInput;

// Hilo de entrada de teclado
void* inputThread(void* arg);
