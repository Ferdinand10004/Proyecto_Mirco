#pragma once
#include <ncurses.h>
#include <pthread.h>
#include <semaphore.h>
#include <vector>
#include <string>
#include <atomic>

// ─── Dimensiones del área jugable ────────────────────────────────────────────
static const int BOARD_W  = 72;   // columnas del tablero
static const int BOARD_H  = 26;   // filas del tablero (sin HUD)
static const int HUD_ROWS = 3;    // filas del HUD superior

// ─── Pares de color ncurses ───────────────────────────────────────────────────
#define CP_DEFAULT  1
#define CP_PLAYER1  2   // verde
#define CP_PLAYER2  3   // magenta
#define CP_ENEMY    4   // rojo
#define CP_BLOCK    5   // cyan
#define CP_PLATFORM 6   // amarillo
#define CP_HUD      7   // amarillo sobre negro
#define CP_WALL     8   // blanco
#define CP_GOAL     9   // verde brillante
#define CP_DANGER  10   // rojo brillante
#define CP_MENU_SEL 11  // negro sobre amarillo (selección en menú)

// ─── Sprites ASCII ────────────────────────────────────────────────────────────
#define SPR_PLAYER1  "[P]"
#define SPR_PLAYER2  "[N]"
#define SPR_ENEMY    ">O<"
#define SPR_BLOCK    "[y]"
#define SPR_INDESTR  "[#]"
#define SPR_PLATFORM "~~~~~~~"
#define SPR_GOAL     "^^^META^^^"
#define SPR_ICICLE   " | "
#define PLATFORM_LEN 7
#define ENEMY_LEN    3
#define PLAYER_LEN   3
#define BLOCK_LEN    3

// ─── Configuración por nivel ──────────────────────────────────────────────────
struct LevelConfig {
    int  enemyCount;
    int  enemySpeedMs;       // ms entre movimientos del enemigo
    int  platformSpeedMs;    // ms entre movimientos de plataforma
    int  platformCount;
    int  blockDensity;       // 0-100 % de bloques en cada fila
    bool hasFallingIcicles;
    bool hasIndestructibleBlocks;
};

// ─── Entidades ────────────────────────────────────────────────────────────────
struct Block {
    int  x, y;
    bool destructible;
    bool destroyed;
};

struct Platform {
    int  x, y;
    int  dir;       // +1 derecha, -1 izquierda
    bool active;
};

struct Enemy {
    int  x, y;
    int  dir;       // +1 derecha, -1 izquierda
    bool active;
    int  floorY;    // fila en la que patrulla
};

struct Icicle {
    int  x, y;
    bool active;
};

struct Player {
    int  x, y;
    int  velY;         // velocidad vertical (+: cae, -: sube)
    bool jumping;
    bool onGround;
    bool onPlatform;
    int  platformIdx;  // índice de la plataforma que lo soporta (-1 = ninguna)
    int  lives;
    int  score;
    bool alive;
    int  id;           // 0 = Popo, 1 = Nana
    int  spawnX, spawnY;
    bool recentlyHit;  // inmunidad breve tras golpe
    int  hitTimer;
};

// ─── Estado global del juego ──────────────────────────────────────────────────
struct GameState {
    // ── Jugadores ──────────────────────────────────────────────────────────
    Player players[2];
    int    numPlayers;

    // ── Entidades ──────────────────────────────────────────────────────────
    std::vector<Block>    blocks;
    std::vector<Platform> platforms;
    std::vector<Enemy>    enemies;
    std::vector<Icicle>   icicles;

    // ── Nivel ──────────────────────────────────────────────────────────────
    int         currentLevel;   // 1, 2 o 3
    LevelConfig levelCfg;
    int         goalY;          // fila de la meta

    // ── Flags de control ──────────────────────────────────────────────────
    std::atomic<bool> running;
    std::atomic<bool> paused;
    std::atomic<bool> gameOver;
    std::atomic<bool> levelComplete;
    std::atomic<bool> gameWon;
    std::atomic<bool> changingLevel;

    // ── Offset de centrado ─────────────────────────────────────────────────
    int offsetX, offsetY;

    // ── Sincronización ────────────────────────────────────────────────────
    pthread_mutex_t mutex;      // protege todo el estado compartido + ncurses
    sem_t           renderSem;  // el hilo de eventos hace post cuando hay update
    sem_t           pauseSem;   // usado para reanudar hilos en pausa

    GameState() : running(false), paused(false), gameOver(false),
                  levelComplete(false), gameWon(false), changingLevel(false) {}
};

// ─── Funciones declaradas en Game.cpp ────────────────────────────────────────
void initColors();
void loadLevel(GameState& gs, int level);
void resetPlayers(GameState& gs);
void setupNCurses();
void calcOffset(GameState& gs);
bool checkTermSize();
