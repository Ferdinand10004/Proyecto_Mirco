#pragma once
#include "Game.h"

// Argumento para el hilo de jugador
struct PlayerThreadArg {
    GameState* gs;
    int        playerIdx;  // 0 = Popo, 1 = Nana
};

// Hilo de cada jugador: maneja movimiento, salto, gravedad, colisiones
void* playerThread(void* arg);

// Detección de colisión jugador-bloque (AABB de 1 celda)
bool collidesWithBlock(GameState& gs, int px, int py, int& blockIdx, bool checkAbove);

// Detección de colisión jugador-plataforma
bool collidesWithPlatform(GameState& gs, int px, int py, int& platIdx);
