#include "ScoreManager.h"
#include <fstream>
#include <algorithm>

// ─── Cargar puntajes desde archivo ────────────────────────────────────────────
std::vector<ScoreEntry> loadScores(const std::string& filename) {
    std::vector<ScoreEntry> entries;
    std::ifstream file(filename);

    if (!file.is_open()) {
        // Si no existe, devolver puntajes por defecto
        entries.push_back({"Popo",   500, 3});
        entries.push_back({"Nana",   350, 2});
        entries.push_back({"IceMan", 200, 1});
        return entries;
    }

    std::string name;
    int score, level;
    while (file >> name >> score >> level) {
        entries.push_back({name, score, level});
    }
    file.close();

    // Ordenar de mayor a menor puntaje
    std::sort(entries.begin(), entries.end(),
              [](const ScoreEntry& a, const ScoreEntry& b) {
                  return a.score > b.score;
              });

    // Mantener solo los top 10
    if (entries.size() > 10) entries.resize(10);

    return entries;
}

// ─── Guardar nuevo puntaje ────────────────────────────────────────────────────
void saveScore(const std::string& filename, const std::string& name,
               int score, int level) {
    // Cargar existentes
    auto entries = loadScores(filename);

    // Agregar nuevo
    entries.push_back({name, score, level});

    // Reordenar
    std::sort(entries.begin(), entries.end(),
              [](const ScoreEntry& a, const ScoreEntry& b) {
                  return a.score > b.score;
              });
    if (entries.size() > 10) entries.resize(10);

    // Escribir al archivo
    std::ofstream file(filename, std::ios::trunc);
    if (!file.is_open()) return;

    for (auto& e : entries) {
        file << e.name << " " << e.score << " " << e.level << "\n";
    }
    file.close();
}
