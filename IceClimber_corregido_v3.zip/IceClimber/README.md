# Ice Climber — CC3086 Programación de Microprocesadores

Versión en consola del clásico arcade **Ice Climber** desarrollada en C++ con `pthreads` y `ncurses`.  
Proyecto 2 – Fase 3 | Universidad del Valle de Guatemala.

**Integrantes:**
- David Magdaleno Ibaté Pérez – 251732
- David Fernando Gonzalez Canel – 251429
- Jose Ignacio Guardado Larios – 25555

---

## Descripción

Uno o dos jugadores ascienden una montaña de hielo rompiendo bloques, usando plataformas móviles y esquivando enemigos en **3 niveles con dificultad progresiva**.

---

## Librerías usadas

| Librería | Propósito |
|---|---|
| `<ncurses.h>` | Interfaz gráfica en consola, colores, entrada no bloqueante |
| `<pthread.h>` | Hilos POSIX para cada entidad del juego |
| `<semaphore.h>` | Semáforos POSIX para sincronización |
| `<unistd.h>` | `usleep()` para controlar velocidades |

---

## Instalación de dependencias

```bash
sudo apt update
sudo apt install libncurses5-dev libncursesw5-dev
```

---

## Compilación

```bash
make
```

O directamente:

```bash
g++ -std=c++17 src/*.cpp -o ice_climber -lncurses -lpthread
```

---

## Ejecución

```bash
./ice_climber
```

> La terminal debe tener al menos **74 columnas × 30 filas**.

---

## Controles

### Jugador 1 — Popo `[P]`
| Tecla | Acción |
|---|---|
| `A` | Mover izquierda |
| `D` | Mover derecha |
| `W` | Saltar / golpear bloque desde abajo |

### Jugador 2 — Nana `[N]`
| Tecla | Acción |
|---|---|
| `←` | Mover izquierda |
| `→` | Mover derecha |
| `↑` | Saltar / golpear bloque desde abajo |

### Globales
| Tecla | Acción |
|---|---|
| `P` | Pausar / Reanudar |
| `Q` / `ESC` | Salir |
| `R` (fin) | Reiniciar partida |
| `M` (fin) | Volver al menú |

---

## Modos de juego

- **Modo 1 jugador**: Solo Popo. El jugador llega a la meta para avanzar de nivel.
- **Modo 2 jugadores**: Popo y Nana comparten teclado. **Cualquiera de los dos que llegue a la meta** hace avanzar al equipo completo al siguiente nivel.

---

## Sistema de niveles

| Nivel | Enemigos | Vel. enemigos | Plataformas | Vel. plataformas | Extras |
|---|---|---|---|---|---|
| 1 | 3 | Lento (600ms) | 2 | Lento (700ms) | — |
| 2 | 5 | Medio (400ms) | 3 | Medio (500ms) | Bloques indestructibles `[#]` |
| 3 | 7 | Rápido (250ms) | 4 | Rápido (300ms) | Bloques indestructibles + Carámbanos `\|` cayendo que quitan vidas |

El jugador conserva **vidas y puntaje acumulado** al pasar de nivel. Se implementan **3 niveles** porque representan claramente dificultad baja, media y alta, que es suficiente para demostrar progresión sin aumentar innecesariamente el riesgo de errores.

---


### Daño e invulnerabilidad

En el nivel 3, los carámbanos/obstáculos que caen desde arriba sí hacen daño: si impactan a Popo o Nana, el jugador pierde una vida, reaparece en su punto inicial y recibe una invulnerabilidad breve. Durante esa invulnerabilidad el personaje parpadea, evitando que pierda varias vidas por un solo choque.

El salto fue ajustado a una altura moderada para que el personaje pueda subir escalones sin elevarse demasiado.

## Puntaje

| Acción | Puntos |
|---|---|
| Romper bloque `[y]` | +10 |
| Completar un nivel | +100 |
| Ganar el juego (superar nivel 3) | +300 bonus |

Los puntajes se guardan en `scores.txt` y se muestran en el menú de **Puntajes Altos**.

---

## Arquitectura de hilos

El juego usa **7 hilos POSIX concurrentes** durante una partida:

| Hilo | Función | Descripción |
|---|---|---|
| `renderThread` | `void*` | Dibuja el estado del juego en tiempo real con ncurses |
| `inputThread` | `void*` | Lee teclado de forma no bloqueante y actualiza flags |
| `playerThread` (×1-2) | `void*` | Física, movimiento, salto, gravedad, colisiones del jugador |
| `enemiesThread` | `void*` | Movimiento autónomo de todos los enemigos |
| `platformThread` | `void*` | Movimiento horizontal de todas las plataformas |
| `eventThread` | `void*` | Verifica Game Over, carámbanos y otros eventos globales |

---

## Mecanismos de sincronización

### `pthread_mutex_t mutex`
Protege **todo el estado compartido** del juego (posiciones, vidas, puntaje, bloques, etc.) y las llamadas a ncurses. Cualquier hilo que lea o modifique el estado hace `pthread_mutex_lock` / `pthread_mutex_unlock`.

### `sem_t renderSem` (semáforo)
Coordina el renderizado: los hilos de física hacen `sem_post(&gs.renderSem)` cada vez que actualizan el estado. El `renderThread` hace `sem_wait(&gs.renderSem)` y solo dibuja cuando hay datos nuevos, evitando ciclos de CPU innecesarios.

### `sem_t pauseSem` (semáforo)
Reservado para la funcionalidad de pausa/reanudar. Cuando el juego se pausa, los hilos comprueban `gs.paused` antes de cada tick; al reanudar, el hilo de input hace `sem_post` múltiple para despertar hilos bloqueados.

---

## Representación ASCII

| Sprite | Elemento | Color |
|---|---|---|
| `[P]` | Jugador 1 – Popo | Verde |
| `[N]` | Jugador 2 – Nana | Magenta |
| `>O<` | Enemigo (Topi) | Rojo |
| `[y]` | Bloque de hielo (destructible) | Cyan |
| `[#]` | Bloque indestructible | Blanco |
| `~~~~~~~` | Plataforma móvil | Amarillo |
| `^^^META^^^` | Meta / cima | Verde |
| ` \| ` | Carámbano (nivel 3) | Rojo |
| `=` | Suelo / bordes | Blanco |

---

## Estructura del proyecto

```
IceClimber/
├── Makefile
├── README.md
├── scores.txt          (generado al jugar)
└── src/
    ├── main.cpp        — Loop principal, gestión de hilos y niveles
    ├── Game.h/cpp      — Estado global, estructuras, loadLevel
    ├── Renderer.h/cpp  — Hilo de renderizado con ncurses
    ├── Input.h/cpp     — Hilo de entrada de teclado
    ├── Player.h/cpp    — Hilo de jugador (física + colisiones)
    ├── Enemy.h/cpp     — Hilo administrador de enemigos
    ├── Platform.h/cpp  — Hilo de plataformas móviles
    ├── Event.h/cpp     — Hilo de eventos globales
    ├── Menu.h/cpp      — Menú, instrucciones, puntajes
    └── ScoreManager.h/cpp — Lectura/escritura de scores.txt
```
